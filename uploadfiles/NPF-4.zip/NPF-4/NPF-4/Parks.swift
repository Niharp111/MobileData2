//
//  Parks.swift
//  NPF-3
//
//  Created by Student on 4/9/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class Parks {
    var parkList : [Park]? = []
}

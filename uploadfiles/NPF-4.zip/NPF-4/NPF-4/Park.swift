//
//  Park.swift
//  NPF-1
//
//  Created by Prasanna Balasubramanian on 2/11/17.
//  Copyright © 2017 Prasanna Balasubramanian. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

class Park: NSObject,MKAnnotation {
    private var parkName : String = ""
    private var parkLocation : String = ""
    private var dateFormed : String = ""
    private var area : String = ""
    private var link : String = ""
    
    private var location : CLLocation? = nil
    private var imageLink : String = ""
    private var parkDescription : String = ""
    
    
    private var imageName : String = ""
    private var imageSize : String = ""
    private var imageType : String = ""
    
    var coordinate: CLLocationCoordinate2D {
        get {
            return location!.coordinate
        }
    }
    
    var title : String? {
        get {
            return parkName
        }
    }

    
    var subtitle : String? {
        get {
            return parkLocation
        }
    }

    
    func getimageName() -> String {
        return imageName
    }
    func set(imageName: String) {
        self.imageName = imageName
    }
    
    func getimageSize() -> String {
        return imageSize
    }
    func set(imageSize: String) {
        self.imageSize = imageSize
    }
    
    func getimageType() -> String {
        return imageType
    }
    func set(imageType: String) {
        self.imageType = imageType
    }
    
    
    func getParkName() -> String {
        return parkName
    }
    func set(name: String) {
        var flag: Bool
        let name = name.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        flag = self.validationCode(input: name)
        if (flag == true){
                self.parkName = name
        }
        else{
            print("Bad value of \(name) in setParkName: setting to TBD")
            self.parkName = "TBD"
        }
        
    }
    
    func getparkLocation() -> String {
        return parkLocation
    }
    func set(location: String) {
        var flag: Bool
        let location = location.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        flag = self.validationCode(input: location)
        if (flag == true){
            self.parkLocation = location
        }
        else{
            print("Bad value of \(location) in setParkLocation: setting to TBD")
            self.parkLocation = "TBD"
        }
    }
    
    func getdateFormed() -> String {
        return dateFormed
    }
    func set(date: String) {
        self.dateFormed = date
    }
    
    func getarea() -> String {
        return area
    }
    func set(strArea: String) {
        self.area = strArea
    }
    
    func getlink() -> String {
        return link
    }
    func set(strLink: String) {
        self.link = strLink
    }
    
    func getLocation() -> CLLocation {
        return location!
    }
    func set(strCLLocation: CLLocation?) {
        self.location = strCLLocation
    }
    
    func getImageLink() -> String {
        return imageLink
    }
    func set(strImageLink: String) {
        self.imageLink = strImageLink
    }
    
    func getParkDescription() -> String {
        return parkDescription
    }
    func set(strParkDescription: String) {
        self.parkDescription = strParkDescription
    }
    
    override var description: String{
        return "{\n\tparkname: \(parkName)\n\tparkLocation: \(parkLocation)\n\tdateFormed: \(dateFormed)\n\tarea: \(area)\n\tlink: \(link)\n\tlocation: \(location)\n\timageLink: \(imageLink)\n\tparkDescription: \(parkDescription)\n\timageName: \(imageName)\n\timageSize: \(imageSize)\n\timageType: \(imageType)\n}"
    }
    
    override convenience init () {
        self.init(parkName: "Unknown", parkLocation: "Unknown", dateFormed: "Unknown", area: "Unknown", link: "Unknown", location: nil, imageLink: "Unknown", parkDescription: "Unknown",imageName: "Unknown", imageSize: "Unknown", imageType: "Unknown")
        

    }
    
    init(parkName: String, parkLocation: String, dateFormed: String, area: String, link: String, location: CLLocation?, imageLink: String, parkDescription: String, imageName: String, imageSize: String, imageType: String){
        super.init()
        set(name: parkName)
        set(location: parkLocation)
        set(date: dateFormed)
        set(strArea: area)
        set(strLink: link)
        
        set(strCLLocation: location)
        set(strImageLink: imageLink)
        set(strParkDescription: parkDescription)
    
        set(imageName: imageName)
        set(imageSize: imageSize)
        set(imageType: imageType)
        
    }
    
    func validationCode(input: String)-> Bool{
        
        if(input.characters.count<=2 || input.characters.count>75){
            return false
        }
        else if  (input.characters.filter{$0 == " "}.count == input.characters.count){
            return false
        }
        return true
    }
}

//
//  AboutViewController.swift
//  NPF-4
//
//  Created by Student on 4/30/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit
import AVFoundation

class AboutViewController: UIViewController {
    let HA_HA_FILE = "Chickadee-call"
    let HA_HA_FORMAT = "mp3"
    
    var player: AVAudioPlayer?
    
    required init?(coder aDecoder: NSCoder) {
        
        if let soundFilePath = Bundle.main.path(forResource: HA_HA_FILE, ofType: HA_HA_FORMAT) {
            
            let fileUrl = URL(fileURLWithPath: soundFilePath)
            
            do {
                player = try AVAudioPlayer(contentsOf: fileUrl)
            } catch let error as NSError {
                player = nil
                print(error)
            }
        } else{
            player = nil
        }
        player?.prepareToPlay()
        super.init(coder: aDecoder)
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        if player != nil {
            player?.play()
        }

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if player != nil {
            player?.play()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBOutlet weak var soundMusic: UIButton!
    
    
    @IBAction func stopSound(_ sender: Any) {
        if player != nil {
            player?.stop()
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

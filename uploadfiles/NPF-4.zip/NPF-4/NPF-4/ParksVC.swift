//
//  FirstViewController.swift
//  NPF-4
//
//  Created by Student on 4/29/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit
import CoreLocation

class ParksVC: UITableViewController {
    
    var parkList = Parks()
    var mapVC: MapVC!
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
       
    var parkDistance: [String:Double] = [:]
    var sortedParkNames : [String] = []
    static var location : CLLocation?
    
    var parks : [Park] {
        get {
            
            return self.parkList.parkList!
            
        }
        set(val) {
            self.parkList.parkList = val
            
        }
    }
    
  
    
    @IBAction func segmentedControlPressed(_ sender: Any) {
        
        
        if segmentedControl.selectedSegmentIndex == 0 {
            parks.sort(by: { (Park1, Park2) -> Bool in
                return Park1.getParkName() < Park2.getParkName()
            })
            
            tableView.reloadData()
            
        }
        
        
        if segmentedControl.selectedSegmentIndex == 1 {
            parks.sort{ (Park1, Park2) -> Bool in
                return Park1.getParkName() > Park2.getParkName()
            }
            tableView.reloadData()
            
        }
        


        
    }
    

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return parks.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ParkCell", for: indexPath)
        
        let parking = parks[indexPath.row]
        cell.textLabel?.text = parking.getParkName()
        

        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let park = parks[indexPath.row]
        let detailVC = ParkDetailTableVC(style: .grouped)
        detailVC.title = park.title
        detailVC.park = park
        detailVC.zoomDelegate? = mapVC
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        //calculateDistance()
        print("##################### parks.count = \(parks.count) ###########################")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


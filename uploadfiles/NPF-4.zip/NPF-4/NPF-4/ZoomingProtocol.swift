//
//  ZoomingProtocol.swift
//  NPF-4
//
//  Created by Student on 4/30/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation
import MapKit
protocol ZoomingProtocol {
    func zoomOnAnnotation(_ annotation:MKAnnotation)
}

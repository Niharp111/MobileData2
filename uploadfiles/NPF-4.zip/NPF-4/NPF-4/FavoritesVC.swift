//
//  FavoriteTableVC.swift
//  NPF-4
//
//  Created by Atir Petkar on 4/25/16.
//  Copyright © 2016 Atir Petkar. All rights reserved.
//

import UIKit

class FavoritesVC: UITableViewController {
    
    //might have to remove it
    static var favorite : [Park] = []
    
    let defaults: UserDefaults = UserDefaults.standard
    
    var fav: [String] = []
    var park: Park!
    
    
    var mapVC : MapVC!
    var zoomDelegate : ZoomingProtocol?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.reloadData()
    }
    

    @IBAction func editPressed(_ sender: Any) {
        if tableView.isEditing == true {
            tableView.setEditing(false, animated: true)
        }else {
            tableView.setEditing(true, animated: true)
            
        }
    }
    //START: to rearrange the favorite parks
    
    
    //determine if a particular row can be moved
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //determines if tableview indents whilst editing
    override func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        let itemToMove = fav[sourceIndexPath.row] // get item we just moved
        fav.remove(at: sourceIndexPath.row)
        fav.insert(itemToMove, at: destinationIndexPath.row)
        
        defaults.set(fav, forKey: "favorites")
        defaults.synchronize()

        
        //        var itemToMove = FavoriteTableVC.favorite[sourceIndexPath.row] // get item we just moved
        //        FavoriteTableVC.favorite.removeAtIndex(sourceIndexPath.row)
        //        FavoriteTableVC.favorite.insert(itemToMove, atIndex: destinationIndexPath.row)
        //
        
        self.tableView.reloadData()
    }
    
    
    //END: to rearrange the favorite park
    
    
    
    
    
    
    
    //make sure the fav list is mutable and gets added with new content, so no need to reload it always when the view will appear
    override func viewWillAppear(_ animated: Bool) {
        
        if defaults.object(forKey: "favorite") != nil {
            fav = defaults.object(forKey: "favorite") as! [String]
        } else {
            fav = []
            defaults.set(fav, forKey: "favorite")
            
        }
        
        //so that favorite array list is reloaded again
        self.tableView.reloadData()
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        defaults.set(fav, forKey: "favorites")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return fav.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavTable", for: indexPath)
        
        
        cell.textLabel?.text = fav[indexPath.row]
        cell.accessoryType = .disclosureIndicator
        
        return cell
    }
    
    
    
    //to delete a row from tableview
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath){
        if editingStyle == .delete {
            fav.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        
        self.tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let park = fav[indexPath.row]
        // zoomDelegate = mapVC
        
        
        
        
        for p in FavoritesVC.favorite {
            //find the park with the same name
            
            
            
            if park == p.getParkName(){
                
                //give it to parkDetailVC
                let detailVC = ParkDetailTableVC(style : .grouped)
                
                detailVC.title = p.getParkName()
                detailVC.park = p
                detailVC.zoomDelegate = mapVC as! ZoomingProtocol?
                //  detailVC.zoomDelegate = ViewController
                navigationController?.pushViewController(detailVC, animated: true)
                
                
                //zoomDelegate?.zoomOnAnnotation(p)
            }
        }
        //let parkDetail = FavoriteTableVC.favorite[park]
        //now pass to mapVC aka ViewController using zoomingProtocol
        zoomDelegate = mapVC
        //  zoomDelegate?.zoomOnAnnotation(park)
        
        
    }
    
    
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

//
//  MapVC.swift
//  NPF-4
//
//  Created by Student on 4/29/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
import Contacts

enum MapType: Int {
    case Standard = 0
    case Satellite
    case Hybrid
}

class MapVC: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, ZoomingProtocol {
    
    var initialValue = true
    var locationManager: CLLocationManager?
    var location: CLLocation?
    var coords: CLLocationCoordinate2D?
    
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var activityController: UIActivityIndicatorView!
    
    @IBOutlet weak var refreshOnClick: UIBarButtonItem!
    
    @IBOutlet weak var mapTypeSegmentedControl: UISegmentedControl!
    
    
    //Zoom out additional feature included
    @IBOutlet weak var doneBtnZoomOut: UIBarButtonItem!
    
    var parkList = Parks()
    
    var parks : [Park] {
        get {
            return self.parkList.parkList!
        }
        
        set(result) {
            self.parkList.parkList = result
        }
    }
    
    @IBAction func mapTypeChanged(sender: AnyObject) {
        // To be implemented
        let mapType = MapType(rawValue: mapTypeSegmentedControl.selectedSegmentIndex)
        switch (mapType!) {
        case .Standard:
            mapView.mapType = MKMapType.standard
        case .Hybrid:
            mapView.mapType = MKMapType.hybrid
        case .Satellite:
            mapView.mapType = MKMapType.satellite
        }
        
    }
    
    
    
    //func zoomOn(annotation:MKAnnotation) - swift 3 way
    func zoomOnAnnotation(_ annotation : MKAnnotation){
        
        tabBarController?.selectedViewController = self
        
        // zoom in
        let region = MKCoordinateRegionMakeWithDistance(annotation.coordinate, 5000, 5000)
        mapView.setRegion(region, animated: true)
        
        mapView.selectAnnotation(annotation, animated: true)
        
    }
    
    required init?(coder aDecoder:NSCoder) {
        
        locationManager = CLLocationManager()
        if CLLocationManager.locationServicesEnabled() {
            locationManager!.requestWhenInUseAuthorization()
            
        }
        
        super.init(coder: aDecoder)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        mapView.delegate = self
        
        locationManager?.delegate = self
        
        //        locationManager?.startUpdatingLocation()
        
        //show user location on mapView
        mapView.showsUserLocation = true
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        mapView.addAnnotations(parks)
    }
    
    
    //Additional feature added
    @IBAction func btnZoomOutPressed(sender: AnyObject){
        
        //        let span = MKCoordinateSpan(latitudeDelta: mapView.region.span.latitudeDelta*2, longitudeDelta: mapView.region.span.longitudeDelta*2)
        //        let region = MKCoordinateRegion(center: mapView.region.center, span: span)
        //
        //        mapView.setRegion(region, animated: true)
        
        var zoomRect: MKMapRect = MKMapRectNull
        for annotation in mapView.annotations {
            let annotationPoint: MKMapPoint = MKMapPointForCoordinate(annotation.coordinate)
            let pointRect: MKMapRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0);
            if (MKMapRectIsNull(zoomRect)) {
                zoomRect = pointRect;
            } else {
                zoomRect = MKMapRectUnion(zoomRect, pointRect);
            }
        }
        mapView.setVisibleMapRect(zoomRect, animated: true)
        
        //allows you to specify additional space arround the edges
        mapView.setVisibleMapRect(zoomRect, edgePadding: UIEdgeInsetsMake(10, 10, 10, 10), animated: true)
        
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        //locationManager will tell the delegate that new location data is available.
        location = locations.last
        stopUpdating()
    }
    
    
    //MARK: - MKMapViewDelegate Methods
    
    // This delegate method is called once for every annotation that is created.
    // If no view is returned by this method, then only the default pin is seen by the user
    func mapView(_ mv: MKMapView, viewFor  annotation: MKAnnotation) -> MKAnnotationView? {
        var view: MKPinAnnotationView
        let identifier = "Pin"
        
        if annotation is MKUserLocation {
            //if annotation is not an MKPointAnnotation (eg. MKUserLocation),
            //return nil so map draws default view for it (eg. blue dot)...
            return nil
        }
        if annotation !== mv.userLocation   {
            //look for an existing view to reuse
            if let dequeuedView = mv.dequeueReusableAnnotationView(withIdentifier: identifier)
                as? MKPinAnnotationView {
                dequeuedView.annotation = annotation
                view = dequeuedView
            } else {
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.pinTintColor = MKPinAnnotationView.purplePinColor()
                view.animatesDrop = true
                view.canShowCallout = true
                //view.calloutOffset = CGPoint(x: -5, y: 5)
                let leftButton = UIButton(type: .infoLight)
                let rightButton = UIButton(type: .detailDisclosure)
                leftButton.tag = 0
                rightButton.tag = 1
                view.leftCalloutAccessoryView = leftButton
                view.rightCalloutAccessoryView = rightButton
            }
            return view
        }
        
        return nil
    }
    
    func mapView(_ mv: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        let parkAnnotation = view.annotation as! Park
        switch control.tag {
        case 0: //left button
            if let url = URL(string: parkAnnotation.getlink()){
                UIApplication.shared.open(url, options: [:], completionHandler: nil)                }
        case 1: //right button
            //            let coordinate = locationManager?.location?.coordinate //make sure location manager has updated before trying to use
            //            let url = String(format: "http://maps.apple.com/maps?saddr=%f,%f&daddr=%f,%f", coordinate!.latitude,coordinate!.longitude,parkAnnotation.getPkLocation()!.coordinate.latitude,(parkAnnotation.getPkLocation()?.coordinate.longitude)!)
            //            UIApplication.shared.open(URL(string: url)!, options: [:], completionHandler: nil)
            
            //--We will use MapKit Item
            
            //get latitiude and longitude
            let location = CLLocation(latitude: parkAnnotation.coordinate.latitude, longitude: parkAnnotation.coordinate.longitude)
            
            let geocoder = CLGeocoder()
            
            var pm: CLPlacemark!
            
            
            
            //reverse geocoding used here
            geocoder.reverseGeocodeLocation(location, completionHandler: {(placemarks, error)->Void in
                //            print(self.location!)
                if error != nil {
                    print("Reverse geocoder failed with error \(error!.localizedDescription)")
                    return
                }
                else if placemarks!.count > 0 {
                    
                    pm = placemarks![0]
                    let location = pm.location
                    self.coords = location!.coordinate
                    
                    //placemark has now street, zip, state, street aka Thoroughfare store  in a addressDict
                    
                    var addressDictionary:[String:String] = [:]
                    
                    print("\(String(describing: pm.addressDictionary? ["Thoroughfare"]))")
                    addressDictionary[String(CNPostalAddressStreetKey)] = pm.addressDictionary! ["Thoroughfare"] as? String
                    addressDictionary[String(CNPostalAddressCityKey)] = pm.addressDictionary! ["City"] as? String
                    addressDictionary[String(CNPostalAddressStateKey)] = pm.addressDictionary! ["State"] as? String
                    addressDictionary[String(CNPostalAddressPostalCodeKey)] = pm.addressDictionary! ["Zip"] as? String
                    //we pass addressDictionary to the park annotations
                    let place = MKPlacemark(coordinate: parkAnnotation.coordinate, addressDictionary: addressDictionary)
                    
                    let mapItem = MKMapItem(placemark: place)
                    
                    let options = [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeDriving]
                    
                    mapItem.openInMaps(launchOptions: options)
                }
            })
            
            
        default:
            break
        }
    }
    
    
    
    @IBAction func refreshOnclick() {
        initialValue = false
        //if intialValue is false, startUpdating method will be called
        startUpdating()
        
        //call parkTableVC to point to user location
        ParksVC.location = location!
    }
    
    
    //UIActivityIndicatorView provides stop and start methods for updating location
    //easier to create start and stop functionalities using UIActivityIndicatorView
    
    func startUpdating(){
        activityController.startAnimating()
        
        //start updating location
        locationManager?.startUpdatingLocation()
    }
    
    func stopUpdating(){
        activityController.stopAnimating()
        
        //stop updating location
        locationManager?.stopUpdatingLocation()
        
        //call parkTableVC to point to user location
        ParksVC.location = location!
        
        //Tapping a button will cause the map to zoom to the user's current location
        
        if !initialValue {
            
            //zoom in to 20000*20000 zoom radius
            let region = MKCoordinateRegionMakeWithDistance(location!.coordinate, 20000, 20000)
            mapView.setRegion(region, animated: true)
        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        locationManager?.desiredAccuracy = kCLLocationAccuracyBest
        locationManager?.startUpdatingLocation()
    }
    
}

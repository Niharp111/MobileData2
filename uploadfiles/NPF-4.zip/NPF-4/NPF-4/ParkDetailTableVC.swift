//
//  SecondViewController.swift
//  NPF-4
//
//  Created by Student on 4/29/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class ParkDetailTableVC: UITableViewController {
    
    var park: Park!
    var zoomDelegate:ZoomingProtocol?
    let defaults: UserDefaults = UserDefaults.standard
    
    let Park_Section = 0
    let location = 1
    let area = 2
    let date = 3
    let img = 4
    let desc = 5
    let url = 6
    let showmap = 7
    let addtofav = 8
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 9
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        var cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier")
        
        if !(cell != nil) {
            cell = UITableViewCell(style: .default, reuseIdentifier: "reuseIdentifier")
        }
        
        switch indexPath.section{
        case Park_Section:
            cell?.textLabel?.text = park.getParkName()
            cell!.textLabel?.textAlignment = .center
        case location:
            cell?.textLabel?.text = park.getparkLocation()
            cell!.textLabel?.textAlignment = .center
        case area:
            cell?.textLabel?.text = park.getarea()
            cell!.textLabel?.textAlignment = .center
        case date:
            cell?.textLabel?.text = park.getdateFormed()
            cell!.textLabel?.textAlignment = .center
        case img:
            var image : UIImage!
            if let imageURL = URL(string: park.getImageLink()){
                if let data = try? Data(contentsOf: imageURL) {
                    image = UIImage(data: data)
                }
            }
            
            cell?.imageView?.image = image
            cell?.imageView!.center = CGPoint(x: cell!.contentView.bounds.size.width/2,y: cell!.contentView.bounds.size.height/2)
        case desc:
            cell?.textLabel?.text = park.getParkDescription()
            cell!.textLabel?.textAlignment = .center
            cell?.textLabel?.numberOfLines = 0
            cell?.textLabel?.lineBreakMode = NSLineBreakMode.byWordWrapping
            
        case url:
            cell!.textLabel?.text = park.getlink()
            cell!.textLabel?.textAlignment = .center
            cell?.textLabel?.numberOfLines = 0
        case showmap:
            cell!.textLabel?.text = "Show On Map"
            cell!.textLabel?.textAlignment = .center
            
        //to be added for button
        case addtofav:
            cell?.textLabel?.text = "Add to Favorites"
            cell?.textLabel?.textAlignment = .center
        default:
            break;
        }
        cell?.textLabel?.numberOfLines = 0
        return cell!

    
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 4 {
            return 220.00
        }
        
        return UITableViewAutomaticDimension
        
    }
    
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 6 {
            if let url = URL(string: park.getlink()){
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                
            }
            
        }
        
        if indexPath.section == 7 {
            zoomDelegate?.zoomOnAnnotation(park)
        }
        
        
        if indexPath.section == 8 {
            var fav:[String] = []
            if defaults.object(forKey: "favorite") != nil {
                fav = defaults.object(forKey: "favorite") as! [String]
            } else {
                fav = []
                
            }
            //make sure the park can be added only once if it does not exist in favorites
            if !fav.contains(park.getParkName()) {
                
                //add it to the favorite list
                FavoritesVC.favorite.append(park)
                
                fav.append(park.getParkName())
                defaults.set(fav, forKey: "favorite")
                
                
                
                //create an alert to show the user that the park is added to favorite list
                let myAlert = UIAlertController(title: "Favorites", message: "\(park.getParkName()) added to favorites", preferredStyle: .alert)
                //add an ok Button to the alert
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                myAlert.addAction(okAction)
                //show it on the current view
                self.present(myAlert, animated: true, completion: nil)
            }
                //else if the park already exists in favorites, notify the user about it
            else {
                let myAlert = UIAlertController(title: "Favorites", message: "\(park.getParkName()) is already added to your favorites", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                myAlert.addAction(okAction)
                self.present(myAlert, animated: true, completion: nil)
                
            }
            
            
        }
        
        tableView.deselectRow(at: indexPath, animated: true)
        

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//
//  FaceView.swift
//  FaceDraw
//
//  Created by Student on 5/3/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class FaceView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    
 
 */
     override func draw(_ rect: CGRect) {
   
      
      let ctx = UIGraphicsGetCurrentContext()
      
      ctx?.setFillColor(UIColor.red.cgColor)
      ctx?.setStrokeColor(UIColor.purple.cgColor)
      ctx?.setLineWidth(8.0)
      
      let bounds = self.bounds
      ctx?.fill(bounds)
        
      let x = bounds.width / 2 - 160
      let y = bounds.height / 2 - 240

       
        let myEllipse = CGRect(x: x + 30, y: y + 300, width: 260, height: 150)

        ctx?.addEllipse(in: myEllipse)
        ctx?.strokePath()
        ctx?.setFillColor(UIColor.yellow.cgColor)
        ctx?.fillEllipse(in: myEllipse)
        
        
        let myTriangle : [CGFloat] = [0.0, 1.0, 0.2, 1.0]
        ctx?.setFillColor(myTriangle)
        ctx?.setLineWidth(8.0)
        
        ctx?.beginPath()
        ctx?.move(to: CGPoint(x: x + 150, y: y + 130))
        ctx?.addLine(to: CGPoint(x: x + 100, y: y + 250))
        ctx?.addLine(to: CGPoint(x: x + 200, y: y + 250))
        ctx?.closePath()
        ctx?.drawPath(using: .fillStroke)

        
        
    let myLeftEye = CGRect(x: x + 40, y: y + 65, width: 75, height: 45)
        
    ctx?.fillEllipse(in: myLeftEye)
    ctx?.strokeEllipse(in: myLeftEye)
        
        let myRightEye = CGRect(x: x + 200 , y: y + 65, width: 75, height: 45)
        
        ctx?.fillEllipse(in: myRightEye)
        ctx?.strokeEllipse(in: myRightEye)
        
        
        let blue : [CGFloat] = [0.0, 0.2, 1.0, 1.0]
        ctx?.setFillColor(blue)
        
        let myLeftPupil = CGRect(x: x + 75, y: y + 78, width: 20, height: 20)
        ctx?.fillEllipse(in: myLeftPupil)
        
        
        let myRightPupil = CGRect(x: x + 215, y: y + 78, width: 20, height: 20)
        ctx?.fillEllipse(in: myRightPupil)
        
        
        let green : [CGFloat] = [0.0, 1.0, 0.2, 1.0]
        ctx?.setFillColor(green)
        ctx?.setLineWidth(4.0)
        
        ctx?.beginPath()
        ctx?.move(to: CGPoint(x: x + 105, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 75, y: y + 314.5))
        ctx?.addLine(to: CGPoint(x: x + 92.5, y: y + 350))
        ctx?.closePath()
        ctx?.drawPath(using: .fillStroke)
        
        
        ctx?.beginPath()
        ctx?.move(to: CGPoint(x: x + 140, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 110, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 125, y: y + 350))
        ctx?.closePath()
        ctx?.drawPath(using: .fillStroke)
        
        ctx?.beginPath()
        ctx?.move(to: CGPoint(x: x + 175, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 145, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 157.5, y: y + 350))
        ctx?.closePath()
        ctx?.drawPath(using: .fillStroke)
       
        ctx?.beginPath()
        ctx?.move(to: CGPoint(x: x + 210, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 180, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 190, y: y + 350))
        ctx?.closePath()
        ctx?.drawPath(using: .fillStroke)
        
        ctx?.beginPath()
        ctx?.move(to: CGPoint(x: x + 245, y: y + 314.5))
        ctx?.addLine(to: CGPoint(x: x + 215, y: y + 302))
        ctx?.addLine(to: CGPoint(x: x + 225.5, y: y + 350))
        ctx?.closePath()
        ctx?.drawPath(using: .fillStroke)
        
    
        
    }
 

}

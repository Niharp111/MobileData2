//
//  ViewController.swift
//  NPF-3
//
//  Created by Student on 4/9/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit


enum MapType: Int {
    case standard = 0
    case satellite
    case hybrid
}

class ViewController: UIViewController,MKMapViewDelegate,CLLocationManagerDelegate {

    var locationManager: CLLocationManager?
    var location: CLLocation?
    var initial = true
    let zoomRadius: CLLocationDistance = 20000

    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var activityController: UIActivityIndicatorView!
    @IBOutlet weak var refreshClicked: UIBarButtonItem!

    @IBOutlet weak var mapTypeSegmentedControl: UISegmentedControl!

    @IBOutlet weak var zoomOut: UIBarButtonItem!
    @IBOutlet weak var zoomIn: UIBarButtonItem!
    
    @IBAction func zoomOut(_ sender: Any) {
        var zoomRect = MKMapRectNull
        for annotation in mapView.annotations {
            let annotationPoint = MKMapPointForCoordinate(annotation.coordinate)
            let pointRect = MKMapRectMake(annotationPoint.x, annotationPoint.y, 0, 0)
            if (MKMapRectIsNull(zoomRect)) {
                zoomRect = pointRect
            } else {
                zoomRect = MKMapRectUnion(zoomRect, pointRect)
            }
        }
        mapView.setVisibleMapRect(zoomRect, edgePadding: UIEdgeInsetsMake(40, 40, 40, 40), animated: true)
    }
    
    
    @IBAction func zoomIn(_ sender: Any) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location!.coordinate, 100000 , 100000)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    var parkList = Parks()
    
    var parks : [Park] {
        get {
            
            return self.parkList.parkList!
            
        }
        set(val) {
            self.parkList.parkList = val
            
        }
    }
    
    required init?(coder aDecoder:NSCoder) {
        
        locationManager = CLLocationManager()
        if CLLocationManager.locationServicesEnabled() {
            locationManager!.requestWhenInUseAuthorization()
            
        }
        
        super.init(coder: aDecoder)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView?.delegate = self
        locationManager?.delegate = self
        locationManager?.startUpdatingLocation()
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        mapView.addAnnotations(parks)
    }
    
    
    @IBAction func refresh() {
        initial = false
        startUpdating()
    }
    
    func startUpdating() {
        activityController.startAnimating()
        locationManager?.startUpdatingLocation()
        
    }
    
    func stopUpdating() {
        activityController.stopAnimating()
        locationManager?.stopUpdatingLocation()
        if initial == false {
            let coordinateRegion = MKCoordinateRegionMakeWithDistance(location!.coordinate, zoomRadius , zoomRadius)
            mapView.setRegion(coordinateRegion, animated: true)
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        location = locations.last
        stopUpdating()
        }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func mapTypeChanged(sender: AnyObject) {
        let mapType = MapType(rawValue: mapTypeSegmentedControl.selectedSegmentIndex)
        switch (mapType!) {
        case .standard:
            mapView.mapType = MKMapType.standard
        case .satellite:
            mapView.mapType = MKMapType.satellite
        case .hybrid:
            mapView.mapType = MKMapType.hybrid
            
        }
    }
    
    func mapView(_ mp: MKMapView, didUpdate userLocation: MKUserLocation) {
        
        //add an annotation
        let point = MKPointAnnotation()
        point.coordinate = userLocation.coordinate
        point.title = "Where am I?"
        point.subtitle = "I am here!"
        
        mapView?.addAnnotation(point)
    }
    
    // This delegate method is called once for every annotation that is created.
    
    // If no view is returned by this method, then only the default pin is seen by the user
    
    
    
    
    func mapView(_ mv: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        var view: MKPinAnnotationView
        
        let identifier = "Pin"
        
        
        if annotation is MKUserLocation {
            
            //if annotation is not an MKPointAnnotation (eg. MKUserLocation),
            
            //return nil so map draws default view for it (eg. blue dot)...
            
            return nil
            
        }
        
        if annotation !== mv.userLocation {
            
            //look for an existing view to reuse
            
            if let dequeuedView = mv.dequeueReusableAnnotationView(withIdentifier: identifier)
                
                as? MKPinAnnotationView {
                
                dequeuedView.annotation = annotation
                
                view = dequeuedView
                
            } else {
                
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                
                view.pinTintColor = MKPinAnnotationView.purplePinColor()
                
                view.animatesDrop = true
                
                view.canShowCallout = true
                
                //view.calloutOffset = CGPoint(x: -5, y: 5)
                
                let leftButton = UIButton(type: .infoLight)
                
                let rightButton = UIButton(type: .detailDisclosure)
                
                leftButton.tag = 0
                
                rightButton.tag = 1
                
                view.leftCalloutAccessoryView = leftButton
                
                view.rightCalloutAccessoryView = rightButton
                
            }
            
            return view
            
        }
        
        
        return nil
        
    }
    
    
    func mapView(_ mv: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        
        let parkAnnotation = view.annotation as! Park
        
        switch control.tag {
            
        case 0: //left button
            
            if let url = URL(string: parkAnnotation.getlink()){
                
                UIApplication.shared.open(url, options: [:], completionHandler: nil) }
            
        case 1: //right button
            
            let coordinate = locationManager?.location?.coordinate //make sure location manager has updated before trying to use
            
            let url = String(format: "http://maps.apple.com/maps?saddr=%f,%f&daddr=%f,%f", (coordinate?.latitude)!,(coordinate?.longitude)!,parkAnnotation.getLocation().coordinate.latitude,parkAnnotation.getLocation().coordinate.longitude)
            
            UIApplication.shared.open(URL(string: url)!, options: [:], completionHandler: nil)
            
        default:
            
            break
            
        }
        
    }


    
    

}

